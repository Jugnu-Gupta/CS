from qiskit import QuantumCircuit, transpile
from qiskit_aer import Aer
from qiskit.visualization import plot_histogram
import matplotlib.pyplot as plt

# Number of qubits for the quantum walk
n = 3  # Number of qubits for the walk

# Initialize the quantum circuit
qc = QuantumCircuit(n)

# Apply Hadamard gate to create a superposition
qc.h(range(n))

# Define the coin operator (CNOT gates)
qc.cx(0, 1)
qc.cx(1, 2)

# Define the shift operator (Hadamard gates)
qc.h(range(n))

# Apply the coin and shift operator iteratively
steps = 2  # Number of steps to simulate
for _ in range(steps):
    qc.cx(0, 1)
    qc.cx(1, 2)
    qc.h(range(n))

# Measure all qubits
qc.measure_all()

# Debug: Visualize the circuit
print("Quantum Circuit:")
print(qc.draw('text'))

# Simulate the quantum walk
backend = Aer.get_backend('aer_simulator')
transpiled_qc = transpile(qc, backend)
result = backend.run(transpiled_qc).result()

# Debug: Check counts
counts = result.get_counts(qc)
print("Measurement results (counts):", counts)

# Plot histogram
plot_histogram(counts)
plt.show()
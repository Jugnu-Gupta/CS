from qiskit_aer import Aer
from qiskit import QuantumCircuit, transpile
from qiskit.visualization import plot_histogram, plot_circuit_layout
import matplotlib.pyplot as plt

# Step 1: Create an entangled Bell state
qc = QuantumCircuit(2)
qc.h(0)          # Apply Hadamard gate on qubit 0
qc.cx(0, 1)      # Apply CNOT gate with qubit 0 as control and qubit 1 as target

# Step 2: Alice applies operations based on the two classical bits she wants to send
# Example: Alice wants to send '11'
qc.z(0)          # Apply Z gate for the second bit (1)
qc.x(0)          # Apply X gate for the first bit (1)

# Step 3: Bob decodes the message
qc.cx(0, 1)      # Apply CNOT gate
qc.h(0)          # Apply Hadamard gate on qubit 0

# Step 4: Measure both qubits
qc.measure_all()

# Visualize the circuit in text format
print(qc.draw('text'))

# Plot the circuit using Matplotlib
circuit_fig = qc.draw('mpl')
plt.title("Quantum Circuit for Superdense Coding")
plt.show()

# Simulate the circuit using Qiskit's Aer simulator
backend = Aer.get_backend('aer_simulator')  # Initialize the simulator
transpiled_qc = transpile(qc, backend)      # Transpile the circuit for the simulator
result = backend.run(transpiled_qc).result()  # Execute the circuit

# Get the result and plot the histogram of the measurement outcomes
counts = result.get_counts(qc)
print("Measurement outcomes:", counts)

# Ensure there are results before plotting
if counts:
    # Qiskit histogram
    plot_histogram(counts)
    plt.title("Superdense Coding: Measurement Outcomes")
    plt.show()

    # Custom Matplotlib plot for counts
    plt.bar(counts.keys(), counts.values(), color='blue')
    plt.xlabel("Measurement Outcomes")
    plt.ylabel("Counts")
    plt.title("Superdense Coding: Measurement Outcomes")
    plt.show()
else:
    print("No measurement outcomes detected.")

import torch
import torch.nn as nn
import torch.optim as optim
import random
import numpy as np
from collections import deque

# -------------------------
# Simple networks
# -------------------------
class Actor(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc = nn.Linear(1, 1)
    def forward(self, x):
        return torch.tanh(self.fc(x))

class Critic(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc = nn.Linear(2, 1)
    def forward(self, s, a):
        x = torch.cat([s, a], dim=1)
        return self.fc(x)

# -------------------------
# Replay buffer (deque)
# -------------------------
buffer = deque(maxlen=5000)   # automatically drops old entries
def store(exp):
    buffer.append(exp)

# -------------------------
# Create networks + targets
# -------------------------
actor = Actor()
critic = Critic()
target_actor = Actor()
target_critic = Critic()
target_actor.load_state_dict(actor.state_dict())
target_critic.load_state_dict(critic.state_dict())

optA = optim.Adam(actor.parameters(), lr=1e-3)
optC = optim.Adam(critic.parameters(), lr=1e-3)

gamma = 0.99
tau   = 0.01
BATCH = 32

# -------------------------
# Fake environment (same dynamics)
# -------------------------
def env_step(s, a):
    s2 = s + a + np.random.randn()*0.1
    r = -abs(s2)
    return s2, r

# -------------------------
# Training loop
# -------------------------
# Optional: use episodes with resets
NUM_EPISODES = 50
STEPS_PER_EP = 40

for ep in range(NUM_EPISODES):
    s = 0.0  # reset state at episode start
    for step in range(STEPS_PER_EP):
        # Select action with noise (inference with no_grad)
        s_t = torch.tensor([[s]], dtype=torch.float32)
        with torch.no_grad():
            a = actor(s_t).item()
        a += np.random.randn()*0.1  # exploration noise

        # Environment step
        s2, r = env_step(s, a)
        store((s, a, r, s2))
        s = s2

        # Update if enough samples
        if len(buffer) >= BATCH:
            batch = random.sample(buffer, BATCH)
            S  = torch.tensor([[b[0]] for b in batch], dtype=torch.float32)
            A  = torch.tensor([[b[1]] for b in batch], dtype=torch.float32)
            R  = torch.tensor([[b[2]] for b in batch], dtype=torch.float32)
            S2 = torch.tensor([[b[3]] for b in batch], dtype=torch.float32)

            # Critic update
            with torch.no_grad():
                A2 = target_actor(S2)
                target_Q = R + gamma * target_critic(S2, A2)
            critic_loss = nn.MSELoss()(critic(S, A), target_Q)

            optC.zero_grad()
            critic_loss.backward()
            optC.step()

            # Actor update
            actor_loss = -critic(S, actor(S)).mean()
            optA.zero_grad()
            actor_loss.backward()
            optA.step()

            # Soft update targets (use copy_)
            for tgt, src in zip(target_actor.parameters(), actor.parameters()):
                tgt.data.copy_(tau * src.data + (1.0 - tau) * tgt.data)
            for tgt, src in zip(target_critic.parameters(), critic.parameters()):
                tgt.data.copy_(tau * src.data + (1.0 - tau) * tgt.data)

    # small progress print
    if (ep+1) % 10 == 0:
        print(f"Episode {ep+1}/{NUM_EPISODES}  buffer={len(buffer)}")

print("DDPG training completed.")


'''
What the script does (short explanation you can say in viva):

Defines tiny linear Actor and Critic PyTorch networks:
Actor: 1→1 linear with tanh so action ∈ [-1,1].
Critic: 2→1 linear that takes [state, action] and outputs Q-value.
Replay buffer: simple Python list buffer with store(exp) that keeps the last 5000 experiences.
Targets: target_actor and target_critic are copies of the main networks and are soft-updated each training step using tau.
Environment: env_step(s,a) defines a toy continuous environment: next state s2 = s + a + noise and reward -abs(s2) (so reward is highest when s2 near 0).
Main loop:
Select action a = actor(state) + gaussian_noise.
Step environment, store (s,a,r,s2).
If enough samples in buffer, sample mini-batch:
Compute target_Q = r + γ * target_critic(s', target_actor(s')).
Minimize MSE between critic(s,a) and target_Q.
Update actor by maximizing critic: loss -mean(critic(s, actor(s))).
Soft-update targets.
After loop it prints completion.
'''
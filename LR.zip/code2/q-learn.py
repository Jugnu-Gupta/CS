"""
Tabular Q-Learning (procedural, no classes)
Environment: simple 4x4 GridWorld (discrete, episodic)

Key parameters you should know:
 - alpha  : learning rate (0 < alpha <= 1). How much the new sample changes Q.
 - gamma  : discount factor (0 <= gamma < 1). Weight of future rewards.
 - epsilon: exploration probability for epsilon-greedy behaviour policy.
 - episodes: number of episodes to train.
 - max_steps: maximum steps per episode (safety cap).
"""

import numpy as np
import matplotlib.pyplot as plt

np.random.seed(42)  # reproducible results

# -----------------------------
# Environment (procedural)
# -----------------------------
GRID_SIZE = 4
N_STATES = GRID_SIZE * GRID_SIZE  # 16 states (0..15)
A_UP, A_DOWN, A_LEFT, A_RIGHT = 0, 1, 2, 3
N_ACTIONS = 4
START_STATE = 0
TERMINAL_STATE = 15  # goal in bottom-right corner


def state_to_pos(s):
    """Convert state index to (row, col)."""
    return divmod(s, GRID_SIZE)


def pos_to_state(row, col):
    """Convert (row, col) to state index."""
    return row * GRID_SIZE + col


def env_step(state, action):
    """
    Take an action in the gridworld.
    Returns: next_state, reward, done
    Deterministic transitions; hitting boundaries keeps you in same cell.
    Reward: -1 per step; 0 at terminal.
    """
    row, col = state_to_pos(state)

    if action == A_UP and row > 0:
        row -= 1
    elif action == A_DOWN and row < GRID_SIZE - 1:
        row += 1
    elif action == A_LEFT and col > 0:
        col -= 1
    elif action == A_RIGHT and col < GRID_SIZE - 1:
        col += 1

    next_state = pos_to_state(row, col)

    if next_state == TERMINAL_STATE:
        return next_state, 0.0, True   # terminal has reward 0
    else:
        return next_state, -1.0, False # step penalty -1


def env_reset():
    """Reset environment to start state."""
    return START_STATE


# -----------------------------
# Epsilon-greedy action selection
# -----------------------------
def epsilon_greedy_action(Q, state, epsilon):
    """
    Choose an action using epsilon-greedy policy derived from Q-table.
    - Q: numpy array of shape (n_states, n_actions)
    - state: current state index
    - epsilon: probability of exploring (choosing random action)
    Returns: action index (int)
    """
    if np.random.rand() < epsilon:
        return np.random.randint(N_ACTIONS)  # explore uniformly
    else:
        # exploit: choose one of the actions with maximum Q (break ties randomly)
        best_actions = np.flatnonzero(Q[state] == Q[state].max())
        return int(np.random.choice(best_actions))


# -----------------------------
# Q-Learning (procedural)
# -----------------------------
def q_learning(alpha=0.5, gamma=0.99, epsilon=0.1, episodes=1000, max_steps=100):
    """
    Perform tabular Q-learning and return learned Q-table and stats.
    - alpha: learning rate
    - gamma: discount factor
    - epsilon: exploration prob
    - episodes: number of training episodes
    - max_steps: maximum steps per episode
    Returns:
      Q: (n_states x n_actions) learned Q-values
      stats: dict with 'returns' and 'lengths' arrays
    """
    Q = np.zeros((N_STATES, N_ACTIONS))  # initialize Q to zero
    returns = np.zeros(episodes)
    lengths = np.zeros(episodes, dtype=int)

    for ep in range(episodes):
        state = env_reset()
        total_reward = 0.0
        done = False

        for t in range(max_steps):
            # choose action from behavior policy (epsilon-greedy)
            action = epsilon_greedy_action(Q, state, epsilon)

            # take action in environment
            next_state, reward, done = env_step(state, action)

            # ----- Q-learning update (off-policy TD) -----
            # target = r + gamma * max_a' Q(next_state, a')
            best_next = np.max(Q[next_state])
            td_target = reward + gamma * best_next
            td_error = td_target - Q[state, action]
            Q[state, action] += alpha * td_error
            # ----------------------------------------------

            total_reward += reward
            state = next_state

            if done:
                lengths[ep] = t + 1
                break

        returns[ep] = total_reward

        # Optional: decay epsilon slowly (commented out — explain in viva)
        # epsilon = max(0.01, epsilon * 0.995)

    stats = {"returns": returns, "lengths": lengths}
    return Q, stats


# -----------------------------
# Helpers to display results
# -----------------------------
def greedy_policy_from_q(Q):
    """Convert Q-table to greedy deterministic policy (array of actions)."""
    return np.argmax(Q, axis=1)


def print_policy(policy):
    """Pretty print policy on grid using arrows."""
    arrow = {A_UP: "^", A_DOWN: "v", A_LEFT: "<", A_RIGHT: ">"}
    for r in range(GRID_SIZE):
        row = policy[r * GRID_SIZE:(r + 1) * GRID_SIZE]
        print(" ".join(arrow[a] for a in row))


# -----------------------------
# Run demo if module executed
# -----------------------------
if __name__ == "__main__":
    # Hyperparameters (explain these in the viva)
    ALPHA = 0.5      # learning rate
    GAMMA = 0.99     # discount factor
    EPSILON = 0.1    # exploration probability
    EPISODES = 1000  # number of episodes to train
    MAX_STEPS = 100  # safety cap per episode

    Q, stats = q_learning(alpha=ALPHA, gamma=GAMMA, epsilon=EPSILON,
                         episodes=EPISODES, max_steps=MAX_STEPS)

    # Display Q-table (rounded for clarity)
    print("Learned Q-table (states 0..15 rows, actions up/down/left/right cols):")
    print(np.round(Q, 2))

    # Derive and show greedy policy
    policy = greedy_policy_from_q(Q)
    print("\nDerived greedy policy (arrows):")
    print_policy(policy)

    # Simple stats
    avg_return_last100 = np.mean(stats["returns"][-100:])
    avg_length = np.mean(stats["lengths"][stats["lengths"] > 0])
    print(f"\nAverage return (last 100 episodes): {avg_return_last100:.2f}")
    print(f"Average episode length (over episodes that finished): {avg_length:.2f}")

    # Plot returns and moving average
    plt.figure(figsize=(8, 4))
    plt.plot(stats["returns"], label="Episode return")
    window = 30
    if len(stats["returns"]) >= window:
        smooth = np.convolve(stats["returns"], np.ones(window) / window, mode="valid")
        plt.plot(np.arange(window - 1, len(stats["returns"])), smooth, label=f"{window}-ep moving avg")
    plt.xlabel("Episode")
    plt.ylabel("Return (sum of rewards)")
    plt.title("Q-Learning (procedural) - Episode returns")
    plt.legend()
    plt.tight_layout()
    plt.show()


# Q is a table of size (states × actions). Q[s,a] estimates expected return when starting from state s, taking action a, then following optimal behavior.
# epsilon_greedy_action picks a random action with probability epsilon (explore), otherwise picks the best action according to Q (exploit).
# The Q-learning update Q[s,a] += alpha * (r + gamma * max Q[s',·] - Q[s,a]) moves the estimate toward the TD target r + gamma * max_a' Q(s',a').
# We use deterministic GridWorld so results are easy to reason about; teachers like that.
# Mention optional extras: decaying epsilon, optimistic initialization of Q (encourages exploration), or using constant vs sample-averaging step-size.
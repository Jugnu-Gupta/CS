import numpy as np

# -------------------------------------------------------
# SIMPLE GRIDWORLD ENVIRONMENT (episodic)
# -------------------------------------------------------
class GridWorld:
    """
    A 4x4 gridworld.
    Start at state 0.
    Terminal states: 0 and 15.
    Reward = -1 per move, 0 at terminal.
    """
    def __init__(self):
        self.size = 4
        self.start_state = 0
        self.terminal_states = [0, 15]
        self.state = self.start_state

    def reset(self):
        """Reset environment to start state."""
        self.state = self.start_state
        return self.state

    def step(self, action):
        """
        Action: 0=up, 1=down, 2=left, 3=right
        Returns: next_state, reward, done
        """
        row, col = divmod(self.state, self.size)

        # Compute new position
        if action == 0 and row > 0:        # up
            row -= 1
        elif action == 1 and row < self.size - 1:  # down
            row += 1
        elif action == 2 and col > 0:      # left
            col -= 1
        elif action == 3 and col < self.size - 1:  # right
            col += 1
        
        new_state = row * self.size + col
        self.state = new_state

        # Terminal check
        if new_state in self.terminal_states:
            return new_state, 0, True      # reward 0 at terminal

        return new_state, -1, False        # step penalty

    def sample_action(self):
        """Uniform random policy over 4 actions."""
        return np.random.randint(0, 4)


# -------------------------------------------------------
# FIRST-VISIT MONTE CARLO PREDICTION
# -------------------------------------------------------
def monte_carlo_prediction(env, episodes=500, gamma=1.0):
    """
    env       : environment object
    episodes  : number of episodes to sample
    gamma     : discount factor
    Returns:
        V: dictionary of value estimates for each state
    """

    # Value function initialized to 0
    V = {s: 0 for s in range(env.size * env.size)}
    # To store all returns for averaging
    returns = {s: [] for s in range(env.size * env.size)}

    for ep in range(episodes):
        trajectory = []  # store (state, reward)

        # 1. Generate an episode using random policy
        state = env.reset()
        done = False

        while not done:
            action = env.sample_action()
            next_state, reward, done = env.step(action)
            trajectory.append((state, reward))
            state = next_state

        # 2. Compute returns G_t from the end of episode backward
        G = 0
        visited_states = set()

        # Traverse the episode backward
        for t in reversed(range(len(trajectory))):
            s, r = trajectory[t]
            G = gamma * G + r

            # First-visit check
            if s not in visited_states:
                returns[s].append(G)
                V[s] = np.mean(returns[s])
                visited_states.add(s)

    return V


# -------------------------------------------------------
# RUN MONTE CARLO
# -------------------------------------------------------
if __name__ == "__main__":
    env = GridWorld()

    V = monte_carlo_prediction(env, episodes=1000)

    print("Monte Carlo Estimated State Values:")
    for s in range(env.size * env.size):
        print(f"State {s:2d}: V(s) = {V[s]:.2f}")


# 1. Episodic environment
# GridWorld is a 4×4 grid.
# Terminal states: 0 and 15.
# Reward = –1 per step, until terminal.
# Simple and easy to explain.
# 2. Monte Carlo prediction
# First-visit MC: only updates value for first time a state appears in an episode.
# Returns are averaged → unbiased value estimate.

# 3. Random behavior policy
# We use uniform random actions, which is okay for prediction (policy evaluation).
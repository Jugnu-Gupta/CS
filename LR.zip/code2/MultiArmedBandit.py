import numpy as np

# -------------------------------------------------------
# K-Armed Bandit Environment
# -------------------------------------------------------
class Bandit:
    def __init__(self, k=5, sigma=1.0):
        """
        k     : number of arms in the bandit (e.g., k=5 means 5 slot machines)
        sigma : standard deviation of the reward distribution.
                Rewards are sampled from Normal(mean, sigma).
        """
        self.k = k
        # Each arm has a true reward mean (unknown to agent)
        self.true_means = np.random.uniform(0, 1, k)
        self.sigma = sigma

    def pull(self, arm):
        """
        Returns a reward sampled from a Normal distribution centered at the true mean.
        """
        return np.random.normal(self.true_means[arm], self.sigma)

    def best_arm(self):
        """Returns the index of the best arm (highest true mean)."""
        return np.argmax(self.true_means)


# -------------------------------------------------------
# Explore Only (Random)
# -------------------------------------------------------
def explore_only(bandit, steps=1000):
    rewards = []
    for _ in range(steps):
        arm = np.random.randint(0, bandit.k)   # choose random arm
        reward = bandit.pull(arm)
        rewards.append(reward)
    return rewards


# -------------------------------------------------------
# Exploit Only (Greedy)
# -------------------------------------------------------
def exploit_only(bandit, steps=1000):
    """
    Always choose the arm with the highest estimated reward.
    No exploration → may get stuck with a bad estimate.
    """
    Q = np.zeros(bandit.k)     # estimated rewards
    N = np.zeros(bandit.k)     # number of times each arm is selected
    rewards = []

    # Initially sample each arm once (to avoid division by zero)
    for arm in range(bandit.k):
        r = bandit.pull(arm)
        Q[arm] = r
        N[arm] = 1
        rewards.append(r)

    # After initial phase, always exploit
    for _ in range(steps - bandit.k):
        arm = np.argmax(Q)     # greedy choice
        r = bandit.pull(arm)
        N[arm] += 1
        Q[arm] = Q[arm] + (r - Q[arm]) / N[arm]   # sample average update
        rewards.append(r)

    return rewards


# -------------------------------------------------------
# Epsilon-Greedy
# -------------------------------------------------------
def epsilon_greedy(bandit, epsilon=0.1, steps=1000):
    """
    epsilon: probability of exploration (random choice)
             With 1 - epsilon → exploit (choose best estimated arm)
    """
    Q = np.zeros(bandit.k)
    N = np.zeros(bandit.k)
    rewards = []

    # Initialize by trying each arm once
    for arm in range(bandit.k):
        r = bandit.pull(arm)
        Q[arm] = r
        N[arm] = 1
        rewards.append(r)

    for _ in range(steps - bandit.k):
        p = np.random.rand()

        if p < epsilon:
            arm = np.random.randint(0, bandit.k)      # explore
        else:
            arm = np.argmax(Q)                        # exploit

        r = bandit.pull(arm)
        N[arm] += 1
        Q[arm] = Q[arm] + (r - Q[arm]) / N[arm]       # update estimate
        rewards.append(r)

    return rewards


# -------------------------------------------------------
# UCB (Upper Confidence Bound)
# -------------------------------------------------------
def ucb(bandit, c=2.0, steps=1000):
    """
    c : controls exploration.
        Higher c => more exploration.
    Formula used:
        UCB = Q[a] + c * sqrt( (ln t) / N[a] )
    """
    Q = np.zeros(bandit.k)
    N = np.zeros(bandit.k)
    rewards = []

    # Try each arm once to initialize
    for arm in range(bandit.k):
        r = bandit.pull(arm)
        Q[arm] = r
        N[arm] = 1
        rewards.append(r)

    # Main loop
    for t in range(bandit.k + 1, steps + 1):
        # Compute UCB values for each arm
        ucb_values = Q + c * np.sqrt(np.log(t) / N)

        arm = np.argmax(ucb_values)        # choose arm with highest UCB
        r = bandit.pull(arm)

        N[arm] += 1
        Q[arm] = Q[arm] + (r - Q[arm]) / N[arm]
        rewards.append(r)

    return rewards


# -------------------------------------------------------
# Driver Code (Runs all algorithms)
# -------------------------------------------------------
if __name__ == "__main__":
    bandit = Bandit(k=5, sigma=1.0)   # create a 5-armed bandit

    print("True means of each arm:", bandit.true_means)
    print("Best arm:", bandit.best_arm())

    steps = 500

    r1 = explore_only(bandit, steps)
    r2 = exploit_only(bandit, steps)
    r3 = epsilon_greedy(bandit, epsilon=0.1, steps=steps)
    r4 = ucb(bandit, c=2.0, steps=steps)

    print("\nAverage Reward:")
    print("Explore only  :", np.mean(r1))
    print("Exploit only  :", np.mean(r2))
    print("ε-greedy      :", np.mean(r3))
    print("UCB           :", np.mean(r4))

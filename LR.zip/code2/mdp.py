"""
Simple tabular MDP utilities + Value Iteration and Policy Iteration.
Meant for small exam/assignment use (finite S, finite A).

How the MDP is represented:
 - S states are 0..(nS-1)
 - A actions are 0..(nA-1)
 - P is a dictionary: P[s][a] = list of (prob, next_state, reward)
   (This is the same format used by OpenAI Gym's discrete envs)
"""

import numpy as np

# -----------------------------
# Example small MDP (2x2 grid)
# -----------------------------
def build_simple_grid_mdp():
    """
    Build a tiny 4-state grid MDP (states 0..3) with 2 actions: 0=left/up, 1=right/down.
    Deterministic transitions for simplicity.
    Rewards:
      - Reaching state 3 gives +1 and is terminal.
      - All other moves give 0 reward.
    Returns: nS, nA, P, terminal_states
    """
    nS = 4
    nA = 2
    P = {s: {a: [] for a in range(nA)} for s in range(nS)}
    terminal_states = {3}

    # Layout (indices):
    # 0 1
    # 2 3 (goal)
    # Actions: 0 -> try move "left/up", 1 -> "right/down"
    # Define transitions:
    # state 0:
    P[0][0] = [(1.0, 0, 0.0)]  # stay if try to move out
    P[0][1] = [(1.0, 1, 0.0)]
    # state 1:
    P[1][0] = [(1.0, 0, 0.0)]
    P[1][1] = [(1.0, 3, 1.0)]  # move to goal (reward+1)
    # state 2:
    P[2][0] = [(1.0, 0, 0.0)]
    P[2][1] = [(1.0, 3, 1.0)]
    # state 3 is terminal: any action stays in 3 with 0 reward
    P[3][0] = [(1.0, 3, 0.0)]
    P[3][1] = [(1.0, 3, 0.0)]

    return nS, nA, P, terminal_states

# -----------------------------
# Value Iteration
# -----------------------------
def value_iteration(nS, nA, P, gamma=0.9, theta=1e-6, max_iters=1000):
    """
    Solves for optimal V using value iteration.
    - nS: number of states
    - nA: number of actions
    - P: transitions in format P[s][a] = [(prob, next_s, reward), ...]
    - gamma: discount
    - theta: small threshold for stopping
    Returns: V (numpy array), policy (numpy array of action indices)
    """
    V = np.zeros(nS)
    for it in range(max_iters):
        delta = 0.0
        for s in range(nS):
            # For terminal-like states where all transitions loop to same state with zero reward,
            # the backups still work; no special casing needed unless you want.
            action_values = np.zeros(nA)
            for a in range(nA):
                val = 0.0
                for (prob, s_next, r) in P[s][a]:
                    val += prob * (r + gamma * V[s_next])
                action_values[a] = val
            max_val = np.max(action_values)
            delta = max(delta, abs(max_val - V[s]))
            V[s] = max_val
        if delta < theta:
            break

    # Extract deterministic greedy policy
    policy = np.zeros(nS, dtype=int)
    for s in range(nS):
        q = np.zeros(nA)
        for a in range(nA):
            for (prob, s_next, r) in P[s][a]:
                q[a] += prob * (r + gamma * V[s_next])
        policy[s] = int(np.argmax(q))
    return V, policy

# -----------------------------
# Policy Iteration
# -----------------------------
def policy_evaluation(policy, nS, nA, P, gamma=0.9, theta=1e-6):
    """
    Evaluate a deterministic policy by iterative policy evaluation.
    Returns V_pi
    """
    V = np.zeros(nS)
    while True:
        delta = 0.0
        for s in range(nS):
            a = policy[s]
            v = 0.0
            for (prob, s_next, r) in P[s][a]:
                v += prob * (r + gamma * V[s_next])
            delta = max(delta, abs(v - V[s]))
            V[s] = v
        if delta < theta:
            break
    return V

def policy_iteration(nS, nA, P, gamma=0.9, max_iters=100):
    """
    Returns final policy and its value after policy iteration.
    """
    # Initialize random policy
    policy = np.zeros(nS, dtype=int)
    for it in range(max_iters):
        V = policy_evaluation(policy, nS, nA, P, gamma)
        policy_stable = True
        for s in range(nS):
            old_a = policy[s]
            # one-step lookahead for greedy action
            q = np.zeros(nA)
            for a in range(nA):
                for (prob, s_next, r) in P[s][a]:
                    q[a] += prob * (r + gamma * V[s_next])
            best_a = int(np.argmax(q))
            policy[s] = best_a
            if best_a != old_a:
                policy_stable = False
        if policy_stable:
            break
    return policy, V

# -----------------------------
# Quick demonstration
# -----------------------------
if __name__ == "__main__":
    nS, nA, P, terminal = build_simple_grid_mdp()

    print("Running Value Iteration...")
    V_vi, pi_vi = value_iteration(nS, nA, P, gamma=0.9)
    print("V (value iteration):", np.round(V_vi, 3))
    print("pi (value iteration):", pi_vi)

    print("\nRunning Policy Iteration...")
    pi_pi, V_pi = policy_iteration(nS, nA, P, gamma=0.9)
    print("V (policy iteration):", np.round(V_pi, 3))
    print("pi (policy iteration):", pi_pi)


# Explain the shape and meaning of P[s][a] entries: (prob, next_state, reward) — teachers like that.
# Mention why γ<1 ensures convergence for infinite horizons (or say it's standard).

#   (exact) or do iterative evaluation — iterative is simpler to code and numerically stable for small examples.
# Explain tradeoffs: value iteration does repeated max backups; policy iteration alternates exact (or iterative) evaluation with improvement and can converge faster in iterations.
# If asked complexity: each backup takes O(|S||A|) per iteration.

# 70% chance go to state 1 and get reward 5
# 30% chance go to state 2 and get reward 0
# P[0][RIGHT] = [
#     (0.7, 1, 5),
#     (0.3, 2, 0)
# ]

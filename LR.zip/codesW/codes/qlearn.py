import random

# states: 0,1,2 | actions: 0,1
Q = [[0,0], [0,0], [0,0]]      # Q-table

# simple transition + reward function
def step(state, action):
    if state == 0 and action == 1:
        return 1, 1     # reward 1, next state = 1
    if state == 1 and action == 1:
        return 2, 2     # reward 2, next state = 2
    return state, 0     # else reward 0, stay same state

alpha = 0.1
gamma = 0.9
epsilon = 0.1

episodes = 200

for ep in range(episodes):
    s = 0          # start state
    for _ in range(10):    # limit steps
        # epsilon-greedy
        if random.random() < epsilon:
            a = random.randint(0,1)
        else:
            a = Q[s].index(max(Q[s]))

        s2, r = step(s, a)

        # Q-learning update
        Q[s][a] = Q[s][a] + alpha * (r + gamma * max(Q[s2]) - Q[s][a])

        s = s2

print("Learned Q-table:")
for row in Q:
    print(row)

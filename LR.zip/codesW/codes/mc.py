import random

# Number of points
N = 100000
inside = 0

for i in range(N):
    x = random.random()       # random number in [0,1]
    y = random.random()

    # check if point is inside the unit circle
    if x*x + y*y <= 1:
        inside += 1

# Monte Carlo estimate of pi
pi = 4 * inside / N
print("Estimated Pi =", pi)

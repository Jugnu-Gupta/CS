import random

# states: 0,1,2 ; 2 is terminal
V = [0.0, 0.0, 0.0]

gamma = 0.9
alpha = 0.1

def step(state):
    if state == 2:
        return 2, 0, True     # terminal: no reward
    next_state = state + 1
    reward = 1 if next_state == 2 else 0
    return next_state, reward, (next_state == 2)

# ----- TD(0) Learning -----
episodes = 50

for _ in range(episodes):
    s = 0
    done = False
    while not done:
        s2, r, done = step(s)

        # TD(0) update rule
        V[s] = V[s] + alpha * (r + gamma * V[s2] - V[s])

        s = s2

print("Learned state values:", V)

import numpy as np

states = [0, 1]                      # A, B
actions = [0, 1]                     # Left, Right

# Transition probabilities P[s][a][s']
P = {
    0: {0: {0:1.0}, 1: {1:1.0}},
    1: {0: {0:1.0}, 1: {1:1.0}}
}

# Rewards R[s][a][s']
R = {
    0: {0:{0:0}, 1:{1:1}},   # going Right from A gives reward 1
    1: {0:{0:0}, 1:{1:2}}    # going Right from B gives reward 2
}

gamma = 0.9
V = [0, 0]                  # initial values

for _ in range(20):         # 20 iterations
    newV = [0, 0]
    for s in states:
        values = []
        for a in actions:
            total = 0
            for s2 in states:
                prob = P[s][a].get(s2, 0)
                reward = R[s][a].get(s2, 0)
                total += prob * (reward + gamma * V[s2])
            values.append(total)
        newV[s] = max(values)     # Bellman update
    V = newV

print("Optimal State Values:", V)

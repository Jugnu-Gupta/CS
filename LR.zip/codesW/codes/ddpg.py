import torch
import torch.nn as nn
import torch.optim as optim
import random
import numpy as np

# ----- Simple Actor Network -----
class Actor(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc = nn.Linear(1, 1)

    def forward(self, x):
        return torch.tanh(self.fc(x))     # action ∈ [-1,1]


# ----- Simple Critic Network -----
class Critic(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc = nn.Linear(2, 1)         # input: [state, action]

    def forward(self, s, a):
        x = torch.cat([s, a], dim=1)
        return self.fc(x)


# ----- Replay Buffer -----
buffer = []
def store(exp):
    if len(buffer) > 5000: buffer.pop(0)
    buffer.append(exp)


# Create networks + targets
actor = Actor()
critic = Critic()
target_actor = Actor()
target_critic = Critic()

target_actor.load_state_dict(actor.state_dict())
target_critic.load_state_dict(critic.state_dict())

optA = optim.Adam(actor.parameters(), lr=1e-3)
optC = optim.Adam(critic.parameters(), lr=1e-3)

gamma = 0.99
tau   = 0.01

# ----- Fake environment -----
def env_step(s, a):
    s2 = s + a + np.random.randn()*0.1
    r = -abs(s2)                       # reward high near 0
    return s2, r


# ----- Training loop -----
s = 0.0
for t in range(2000):

    # Select action with noise
    a = actor(torch.tensor([[s]], dtype=torch.float)).item()
    a += np.random.randn()*0.1

    # Step environment
    s2, r = env_step(s, a)
    store((s, a, r, s2))

    s = s2

    # ----- Update networks -----
    if len(buffer) > 32:
        batch = random.sample(buffer, 32)
        S  = torch.tensor([[b[0]] for b in batch], dtype=torch.float)
        A  = torch.tensor([[b[1]] for b in batch], dtype=torch.float)
        R  = torch.tensor([[b[2]] for b in batch], dtype=torch.float)
        S2 = torch.tensor([[b[3]] for b in batch], dtype=torch.float)

        # ----- Critic loss -----
        A2 = target_actor(S2)
        target_Q = R + gamma * target_critic(S2, A2).detach()
        critic_loss = ((critic(S, A) - target_Q)**2).mean()

        optC.zero_grad()
        critic_loss.backward()
        optC.step()

        # ----- Actor loss -----
        actor_loss = -critic(S, actor(S)).mean()

        optA.zero_grad()
        actor_loss.backward()
        optA.step()

        # ----- Soft update -----
        for target, main in zip(target_actor.parameters(), actor.parameters()):
            target.data = tau * main.data + (1 - tau) * target.data

        for target, main in zip(target_critic.parameters(), critic.parameters()):
            target.data = tau * main.data + (1 - tau) * target.data

print("DDPG training completed.")

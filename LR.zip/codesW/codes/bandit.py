# epsilom greedy
import random

# True rewards of 3 arms (unknown to agent)
true_means = [0.2, 0.5, 0.8]

# Estimates
Q = [0, 0, 0]
N = [0, 0, 0]

epsilon = 0.1
steps = 1000

for t in range(steps):
    # explore
    if random.random() < epsilon:
        action = random.randint(0, 2)
    else:
        action = Q.index(max(Q))     # exploit

    # get reward from chosen arm
    reward = 1 if random.random() < true_means[action] else 0

    # update
    N[action] += 1
    Q[action] += (reward - Q[action]) / N[action]

print("Q-values (estimates):", Q)




# ucb
import math
import random

true_means = [0.2, 0.5, 0.8]
Q = [0, 0, 0]
N = [0.0001, 0.0001, 0.0001]   # avoid divide by zero

steps = 1000

for t in range(1, steps+1):

    # compute UCB values
    UCB = [
        Q[i] + math.sqrt(2 * math.log(t) / N[i])
        for i in range(3)
    ]

    action = UCB.index(max(UCB))

    reward = 1 if random.random() < true_means[action] else 0

    N[action] += 1
    Q[action] += (reward - Q[action]) / N[action]

print("Q-values (UCB Estimates):", Q)




# thompson sampling
import random
import numpy as np

true_means = [0.2, 0.5, 0.8]

# Beta priors: a = successes + 1, b = failures + 1
a = [1, 1, 1]
b = [1, 1, 1]

steps = 1000

for t in range(steps):

    # sample from Beta posterior
    samples = [np.random.beta(a[i], b[i]) for i in range(3)]
    action = samples.index(max(samples))

    reward = 1 if random.random() < true_means[action] else 0

    # update posterior
    if reward == 1:
        a[action] += 1
    else:
        b[action] += 1

print("Posterior a (successes):", a)
print("Posterior b (failures):", b)

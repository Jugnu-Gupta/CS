
import numpy as np
import matplotlib.pyplot as plt

def initialize_superposition(n):
    state = np.ones((2**n,)) / np.sqrt(2**n)
    return state

def oracle(state, target_index):
    state[target_index] *= -1
    return state

def diffusion_operator(state):
    mean = np.mean(state)
    return 2 * mean - state

def simulate_grovers_algorithm(n, target_index, iterations):
    state = initialize_superposition(n)
    print(f"Initial State Vector (Superposition):\n{state}\n")
    for i in range(iterations):
        state = oracle(state, target_index)
        print(f"After Oracle (Iteration {i+1}):\n{state}\n")
        state = diffusion_operator(state)
        print(f"After Diffusion (Iteration {i+1}):\n{state}\n")
    return state

def find_target(state):
    probabilities = np.abs(state)**2
    target_index = np.argmax(probabilities)
    return target_index

n_qubits = 4
target_index = 7
iterations = 3

final_state = simulate_grovers_algorithm(n_qubits, target_index, iterations)

probabilities = np.abs(final_state)**2

x = np.arange(2**n_qubits)

plt.figure(figsize=(12, 6))
plt.bar(x, final_state, color='blue', alpha=0.7)
plt.title("Amplitude Distribution After Grover's Algorithm")
plt.xlabel("State Index")
plt.ylabel("Amplitude")
plt.grid(True)
plt.show()

plt.figure(figsize=(12, 6))
plt.bar(x, probabilities, color='orange', alpha=0.7)
plt.title("Probability Distribution After Grover's Algorithm")
plt.xlabel("State Index")
plt.ylabel("Probability")
plt.grid(True)
plt.show()

predicted_target = find_target(final_state)
print(f"Final State Vector (Amplitudes):\n{final_state}\n")
print(f"Probabilities:\n{probabilities}\n")
print(f"Predicted Target Index: {predicted_target}")
print(f"Actual Target Index: {target_index}")



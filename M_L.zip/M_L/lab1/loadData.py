import pandas as pd

# Load the Titanic dataset from seaborn's built-in dataset
data = pd.read_csv('tested.csv')

# Display the first few rows of the dataset
print("Data Loaded:")
print(data.head())




